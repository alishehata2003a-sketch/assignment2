bart(1)


// Question 1

const path = require("path");

function showPath() {
    console.log(__filename);
    console.log(__dirname);
}

showPath();


// Question 2

const path = require("path");

function getFileName(filePath) {
    return path.basename(filePath);
}

console.log(getFileName("/user/files/report.pdf"));


// Question 3

function buildPath(obj) {
    return path.join(obj.dir, obj.name + obj.ext);
}

console.log(buildPath({ dir: "/folder", name: "app", ext: ".js" }));


// Question 4

function getExtension(filePath) {
    return path.extname(filePath);
}

console.log(getExtension("/docs/readme.md"));


// Question 5

function parsePath(filePath) {
    let result = path.parse(filePath);

    return {
        Name: result.name,
        Ext: result.ext
    };
}

console.log(parsePath("/home/app/main.js"));


// Question 6

function checkPath(filePath) {
    return path.isAbsolute(filePath);
}

console.log(checkPath("/home/user/file.txt"));


// Question 7

function joinPath(part1, part2, part3) {
    return path.join(part1, part2, part3);
}

console.log(joinPath("src", "components", "App.js"));


// Question 8

function resolvePath(filePath) {
    return path.resolve(filePath);
}

console.log(resolvePath("./index.js"));


// Question 9

function joinTwoPaths(path1, path2) {
    return path.join(path1, path2);
}

console.log(joinTwoPaths("/folder1", "folder2/file.txt"));

// Question 10

const fs = require("fs");

function deleteFile(filePath) {
    fs.unlink(filePath, (err) => {
        if (err) {
            console.log(err.message);
        } else {
            console.log("The file is deleted.");
        }
    });
}
// Question 11

function createFolder(folderName) {
    fs.mkdirSync(folderName, { recursive: true });
    console.log("Success");
}

createFolder("./newFolder");


// Question 12

const EventEmitter = require("events");

const emitter = new EventEmitter();

emitter.on("start", () => {
    console.log("Welcome event triggered!");
});

emitter.emit("start");


// Question 13

const EventEmitter = require("events");

const emitter = new EventEmitter();

emitter.on("login", (username) => {
    console.log("User logged in: " + username);
});

emitter.emit("login", "Ahmed");


// Question 14

function readFile(filePath) {
    const data = fs.readFileSync(filePath, "utf8");
    console.log(data);
}

readFile("./notes.txt");


// Question 15

function writeFile(filePath, content) {
    fs.writeFile(filePath, content, (err) => {
        if (err) {
            console.log(err.message);
        } else {
            console.log("File saved");
        }
    });
}

writeFile("./async.txt", "Async save");


// Question 16

function checkDirectory(dirPath) {
    return fs.existsSync(dirPath);
}

console.log(checkDirectory("./notes.txt"));


// Question 17

const os = require("os");

function getOSInfo() {
    return {
        Platform: os.platform(),
        Arch: os.arch()
    };
}

console.log(getOSInfo());


// Question 18

const fs = require("fs");

function readFileChunks(filePath) {
    const stream = fs.createReadStream(filePath);

    stream.on("data", (chunk) => {
        console.log(chunk.toString());
    });
}

readFileChunks("./big.txt");


// Question 19

function copyFile(source, destination) {
    const readStream = fs.createReadStream(source);
    const writeStream = fs.createWriteStream(destination);

    readStream.pipe(writeStream);

    writeStream.on("finish", () => {
        console.log("File copied using streams");
    });
}

copyFile("./source.txt", "./dest.txt");


// Question 20

const zlib = require("zlib");
const { pipeline } = require("stream");

function compressFile(source, destination) {
pipeline(
 fs.createReadStream(source),
 zlib.createGzip(),
 fs.createWriteStream(destination),
 (err) => {
 if (err) {
 console.log(err.message);
 } else {
      console.log("File compressed successfully");
      }
      }
    );
}

compressFile("./data.txt", "./data.txt.gz");





