const express = require("express");
const fs = require("fs");

const app = express();

app.use(express.json());

function readUsers() {
    return JSON.parse(fs.readFileSync("users.json", "utf8"));
}

function writeUsers(users) {
    fs.writeFileSync("users.json", JSON.stringify(users, null, 2));
}

// Q1: Add user
app.post("/user", (req, res) => {
    const users = readUsers();
    const { name, age, email } = req.body;

    for (const id in users) {
        if (users[id].email === email) {
            return res.json({ message: "Email already exists." });
        }
    }

    let id = 1;

    for (const userId in users) {
        if (Number(userId) >= id) {
            id = Number(userId) + 1;
        }
    }

    users[id] = { id, name, age, email };
    writeUsers(users);

    res.json({ message: "User added successfully." });
});

// Q2: Update user
app.patch("/user/:id", (req, res) => {
    const users = readUsers();
    const id = req.params.id;

    if (!users[id]) {
        return res.json({ message: "User ID not found." });
    }

    const { name, age, email } = req.body;

    if (email !== undefined) {
        for (const userId in users) {
            if (userId !== id && users[userId].email === email) {
                return res.json({ message: "Email already exists." });
            }
        }
    }

    if (name !== undefined) users[id].name = name;
    if (age !== undefined) users[id].age = age;
    if (email !== undefined) users[id].email = email;

    writeUsers(users);
    res.json({ message: "User age updated successfully." });
});

// Q3: Delete user
app.delete("/user/:id", (req, res) => {
    const users = readUsers();
    const id = req.params.id;

    if (!users[id]) {
        return res.json({ message: "User ID not found." });
    }

    delete users[id];
    writeUsers(users);

    res.json({ message: "User deleted successfully." });
});

// Q4: Get all users
app.get("/user", (req, res) => {
    const users = readUsers();
    const result = [];

    for (const id in users) {
        result.push(users[id]);
    }

    res.json(result);
});

// Q5: Get user by ID
app.get("/user/:id", (req, res) => {
    const users = readUsers();
    const id = req.params.id;

    if (!users[id]) {
        return res.json({ message: "User ID not found." });
    }

    res.json(users[id]);
});

app.listen(3000, () => {
    console.log("Server is running on port 3000");
});
